public class DogRescue extends DogList
{
private String dogName;
private double vetCost;
private double foodCost;



public void setName(String name)
{
dogName = name;
}

public String getName()
{
return dogName;
}

public void setVetCost(double vet)
{
vetCost = vet;
}

public double getVetCost()
{
return vetCost;
}

public void setFoodCost(double food)
{
foodCost = food;
}

public double getFoodCost()
{
return foodCost;
}










}